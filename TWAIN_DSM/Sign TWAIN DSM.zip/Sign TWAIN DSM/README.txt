Use this kit to sign TWAIN Data Source Manager files.  These instructions
are for a developer building the DSM, and for the TWAIN Administrator.

********************************************************************************
Only the TWAIN Administrator can have the TwainWorkingGroupCertificate.pfx file,
so if sharing this folder with a developer be sure to delete it!
********************************************************************************

If you're doing this for the first time, please download and install
Visual Studio Community (free version).  Make sure the checkbox is
selected for the Visual Studio SDK, and the SDK for the latest version
of Windows, since this is what's needed to get the signtool program.
If you already have Visual Studio installed, you make need to update
your copy to install the SDKs.

If you're doing this for the first time, please install 7-zip which is
included in this folder: 7z1604-x64.msi

The file TwainWorkingGroupCertrificate.pfx is the digital signing certificate.
If a new one is received make sure it's renamed to TwainWorkingGroup.pfx.
It may be necessary to install the certificate and then export it.  To
get to the certificate manager on Windows 10, click on the Start box in
the lower left corner and type: manage user certificates. The TWAIN
Working Group certificate should be under "Personal", right click on it,
and select All Tasks / Export, check boxes that specify that extended
data should be included, be careful to NOT click the checkbox that will
delete the certificate when done (that would be bad).



[DEVELOPER PRE-SIGNING INSTRUCTIONS]
A developer creates a TWAINDSM folder in this folder, which is laid out
like this:
	TWAINDSM\32\TWAINDSM.dll
	TWAINDSM\64\TWAINDSM.dll

The files come from the following folders after successfully buildings
the TWAIN DSM (replace the ... with the root of the folders on your system):
	...\twain-dsm\TWAIN_DSM\pub\bin\twain32
	...\twain-dsm\TWAIN_DSM\pub\bin\twain64

The developer then runs the "Create TWAINDSM.zip.bat" script, which zips
this up with a password of twg. The resulting "TWAINDSM.zip" is sent to
sent to the TWAIN Administrator for signing.



[TWAIN ADMINISTRATOR INSTRUCTIONS]
The TWAIN Administrator copies the TWAINDSM.zip file into this folder,
and runs the "Sign Twain DSM.bat" script.  The resulting "TWAINDSM_Signed.zip"
is sent back to the developer for releasing on GitHub.



[DEVELOPER POST-SIGNING INSTRUCTIONS]
Unzip the "TWAINDSM_Signed.zip" file and copy the files back into the pub folder:
	TWAINDSM\32\TWAINDSM.dll --> ...\twain-dsm\TWAIN_DSM\pub\bin\twain32\
	TWAINDSM\64\TWAINDSM.dll --> ...\twain-dsm\TWAIN_DSM\pub\bin\twain64\

When that is done, bring up visual studio, load the merge module solution, and
do a full release build.  This creates the corresponding .MSM merge modules files.
Copy these to the Releases folder under a new version, and commit and push them
to github (don't forget to add the new folder before committing).
